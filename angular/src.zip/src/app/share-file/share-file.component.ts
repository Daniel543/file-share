import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import {Router} from '@angular/router';
import {ApiService} from '../common/api.service';
import {File} from '../model/file.model';


@Component({
  selector: 'app-share-file',
  templateUrl: './share-file.component.html',
  styleUrls: ['./share-file.component.css']
})
export class ShareFileComponent implements OnInit {

  shareForm: FormGroup;
  users: any;
  file: string;

  constructor(private formBuilder: FormBuilder,private router: Router, private apiService: ApiService) { }
  ngOnInit() {
    if (!window.sessionStorage.getItem('token')) {
      this.router.navigate(['login']);
      return;
    }
    let fileId = window.sessionStorage.getItem("shareFileId");
    if(!fileId) {
      alert("Action not permitted.")
      this.router.navigate(['']);
      return;
    }
    this.file = fileId;
    this.shareForm = this.formBuilder.group({
      username: ['', Validators.required]
    });
    this.apiService.getUsersForFile(fileId)
      .subscribe(data => {
        console.log(data);
        this.users = data;
      });
  }

  remove(user): void {
    this.apiService.removeUserAccesToFile(user.userId, this.file)
      .subscribe(data => {
        this.files = this.files.filter(u => u !== file);
      });
  }

}
