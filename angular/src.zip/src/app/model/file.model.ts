export class File {

  fileId: number;

}
