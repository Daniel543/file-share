export class User {

  userId: number;

}
